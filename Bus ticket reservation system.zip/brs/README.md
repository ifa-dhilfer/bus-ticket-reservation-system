# OnlineBusReservationSystem
An Online bus ticket servicing system Using PHP. It can be used as user Thesis project.If You like please feel free to commit. 



admin panel:
username: admin
password: admin